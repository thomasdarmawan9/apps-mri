<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_dashboard extends CI_Model {

	public function contruct(){
		parent::__construct();
	}

	public function get_my_overtime(){
		$this->db->select('SUM(nilai) as nl', false);
		$this->db->where('id_user',$this->session->userdata('id'));
		$query = $this->db->get('lembur');

		foreach($query->result() as $ot){
			$over = $ot-> nl;
		}

		return $over;

	}
	
	public function get_all_photo(){
	    $where = "picture is  NOT NULL";
        $this->db->where($where);
        $this->db->where('status','aktif');
        $this->db->where('level','user');
        $this->db->order_by('id', 'RANDOM');
        
        $query = $this->db->get('user');
        
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
        
	}
	
	public function get_birthdate(){
	    $this->db->where('DAY(birthday)', date('d'));
	    $this->db->where('MONTH(birthday)', date('m'));
	    
	    $query = $this->db->get('user');
	    
	    if($query->num_rows() > 0){
	        return $query->result();
	    }else{
	        return false;
	    }
	}

	public function get_my_cutiizin(){

		$this->db->select('YEAR(tgl) as thn, SUM(plus) as pl, SUM(nilai) as nl');
		$this->db->where('id_user',$this->session->userdata('id'));
		$query = $this->db->get('cuti_izin');

		foreach($query->result() as $izin){
			$cuti_izin_plus = $izin-> pl;
			$cuti_izin_minus = $izin-> nl;
		}

		$izin = $cuti_izin_plus - $cuti_izin_minus;
		return $izin;
	}

	public function get_my_cutisakit(){

		$this->db->select('YEAR(tgl) as thn, SUM(plus) as pl, SUM(nilai) as nl');
		$this->db->where('YEAR(tgl)', date('Y'));
		$this->db->where('id_user',$this->session->userdata('id'));
		$query = $this->db->get('cuti_sakit');

		foreach($query->result() as $sakit){
			$cuti_sakit_plus = $sakit-> pl;
			$cuti_sakit_minus = $sakit-> nl;
		}

		$sakit = $cuti_sakit_plus - $cuti_sakit_minus;

		return $sakit;
	}

	// public function getuser(){

	// 	$where = '(status="aktif" or status is null)';
	// 	$this->db->where($where);

	// 	$query = $this->db->get('user');
	// 	if ($query -> num_rows() > 0){
	// 		return $query->result();
	// 	}else{
	// 		return false;
	// 	}
	// }

	public function get_data_dashboard_admin(){
		$start = date('Y').'-01-01';
		$now = date('Y-m-d');
		
		if($this->session->userdata('is_hr') == true){
    		$divisi = unserialize($this->session->userdata('is_hr_division'));
    		$in = implode(',', $divisi);
    		$query = "	SELECT username, id_divisi, total_lembur, total_cuti_izin, total_cuti_sakit
					FROM user 
					join (SELECT id_user, ifnull(sum(nilai), 0) as total_lembur from lembur group by id_user) lembur
					on user.id = lembur.id_user
					join (SELECT id_user, ifnull(sum(plus), 0) - ifnull(sum(nilai), 0) as total_cuti_izin from cuti_izin group by id_user) izin
					on user.id = izin.id_user
					left join (SELECT id_user, ifnull(sum(plus), 0) - ifnull(sum(nilai), 0) as total_cuti_sakit from cuti_sakit where tgl between '".$start."' and '".$now."' group by id_user) sakit
					on user.id = sakit.id_user
					where (user.status = 'aktif' or user.status is null) and (id_divisi in ($in))";
		}else{
    		$query = "	SELECT username, id_divisi, total_lembur, total_cuti_izin, total_cuti_sakit
					FROM user 
					join (SELECT id_user, ifnull(sum(nilai), 0) as total_lembur from lembur group by id_user) lembur
					on user.id = lembur.id_user
					join (SELECT id_user, ifnull(sum(plus), 0) - ifnull(sum(nilai), 0) as total_cuti_izin from cuti_izin group by id_user) izin
					on user.id = izin.id_user
					left join (SELECT id_user, ifnull(sum(plus), 0) - ifnull(sum(nilai), 0) as total_cuti_sakit from cuti_sakit where tgl between '".$start."' and '".$now."' group by id_user) sakit
					on user.id = sakit.id_user
					where user.status = 'aktif' or user.status is null";
		}
		return $this->db->query($query);
	}

}