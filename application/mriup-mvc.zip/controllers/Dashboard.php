<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Dashboard extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model('model_dashboard');
		$this->load->model('model_login');
	} 
	
	public function _remap($method, $param = array()){
		if(method_exists($this, $method)){
			$level = $this->session->userdata('level');
			if(!empty($level)){
				return call_user_func_array(array($this, $method), $param);
			}else{
				redirect(base_url('login'));				
			}
		}else{
			display_404();
		}
	}

	public function index(){
		if($this->session->userdata('level') == 'admin'){
			$data['results'] = $this->model_dashboard->get_data_dashboard_admin()->result_array();
			set_active_menu('dashboard');
			init_view('content_dashboard_admin', $data);
		}else if($this->session->userdata('level') == 'hr'){
			$data['results'] = $this->model_dashboard->get_data_dashboard_admin()->result_array();
			set_active_menu('dashboard');
			init_view('content_dashboard_admin', $data);
		}else if($this->session->userdata('level') == 'finance'){
			redirect(base_url('finance/signup/confirm'));
		}else if($this->session->userdata('level') == 'viewer'){
			redirect(base_url('viewer/signup/confirm'));
		}else if($this->session->userdata('level') == 'support'){
			redirect(base_url('support/task'));
		}else if($this->session->userdata('level') == 'logistic'){
		    redirect(base_url('logistic/product'));
		}else{			
			$data['overtime'] = $this->model_dashboard->get_my_overtime();
			$data['izin'] = $this->model_dashboard->get_my_cutiizin();
			$data['sakit'] = $this->model_dashboard->get_my_cutisakit();
			
			$data['birthdate'] = $this->model_dashboard->get_birthdate();
			
			if(empty($data['birthdate'])){
			    $data['photo'] = $this->model_dashboard->get_all_photo();
			    //$data['instagram'] = $this->model_login->get_warrior_story();
			}
			
			set_active_menu('dashboard');
			init_view('content_dashboard', $data);
		}
	}

	public function export(){
		if($this->session->userdata('level') == 'admin'){
	        $data = $this->model_dashboard->get_data_dashboard_admin();
	        $filename = 'Laporan All - '.date('Y-m-d');
	       	exportToExcel($data, 'Sheet 1', $filename);
        }else if($this->session->userdata('level') == 'hr'){
        	$data = $this->model_dashboard->get_data_dashboard_admin();
	        $filename = 'Laporan All - '.date('Y-m-d');
	       	exportToExcel($data, 'Sheet 1', $filename);
        }else{
        	display_404();
        }
	}
	

}