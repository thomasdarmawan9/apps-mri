<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

<?php if (!empty($this->session->flashdata('ultah'))){ ?>

        <?php if(!empty($photo)){ ?>
        <link rel="stylesheet" href="<?= base_url('inc/owlcarousel/dist/assets/owl.carousel.min.css'); ?>">
        <link rel="stylesheet" href="<?= base_url('inc/owlcarousel/dist/assets/owl.theme.default.min.css') ?>">
        
         <style>
             #owl-demo .item{
              margin: 3px;
            }
            #owl-demo .item img{
              display: block;
              width: 100%;
              height: auto;
            }
            .owl-next, .owl-prev{
                font-size:15pt !important;
                color:white;
            }
            
            .img-show{
                border-radius: 100px;
            }
         </style>
         
         <script src="<?= base_url('inc/owlcarousel/dist/owl.carousel.min.js'); ?> "></script>
        <script type="text/javascript">
        
            $(document).ready(function(){
              $(".owl-carousel").owlCarousel({
                    loop:true,
                    margin:10,
                    nav:true,
                    responsive:{
                        0:{
                            items:1
                        },
                        600:{
                            items:2
                        },
                        1000:{
                            items:3
                        }
                    }
                });
              $('#photoModal').modal('show');
              $('#photoModal').addClass('animated jello delay-5s');
            });
    
        </script>
        
        <!-- Modal Instagram -->
        <div class="modal fade" id="photoinstaModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="background: #3897f0;color: white;">
                        <h5 class="modal-title" id="exampleModalLabel">Warrior Story</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="container text-center my-3">
                            
                            <div class="owl-carousel">
                                <?php foreach ($instagram as $p){ ?>
                                    <div>
                                            <blockquote class="instagram-media w-100" data-instgrm-permalink="<?= $p->link_warrior_story; ?>" data-instgrm-version="9" style=" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:540px; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);">
                         			            <div style="padding:8px;">
                         			                <div class="w-100" style=" background:#F8F8F8; line-height:0; margin-top:40px; padding:50% 0; text-align:center; width:100%;">
                         			                    <div class="w-100" style=" background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAMAAAApWqozAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAMUExURczMzPf399fX1+bm5mzY9AMAAADiSURBVDjLvZXbEsMgCES5/P8/t9FuRVCRmU73JWlzosgSIIZURCjo/ad+EQJJB4Hv8BFt+IDpQoCx1wjOSBFhh2XssxEIYn3ulI/6MNReE07UIWJEv8UEOWDS88LY97kqyTliJKKtuYBbruAyVh5wOHiXmpi5we58Ek028czwyuQdLKPG1Bkb4NnM+VeAnfHqn1k4+GPT6uGQcvu2h2OVuIf/gWUFyy8OWEpdyZSa3aVCqpVoVvzZZ2VTnn2wU8qzVjDDetO90GSy9mVLqtgYSy231MxrY6I2gGqjrTY0L8fxCxfCBbhWrsYYAAAAAElFTkSuQmCC); display:block; height:44px; margin:0 auto -44px; position:relative; top:-22px; width:44px;">
                         			                        
                         			                    </div>
                         			                </div>
                         			            </div>
                         			        </blockquote> <script async defer src="//www.instagram.com/embed.js"></script>
                                    </div>
                                <?php } ?>
                              
                            </div>
        
            
                        </div>
                    </div>
                    
                    <div class="modal-footer bg-primary">
                        <a href="<?= base_url('user/instagram'); ?>"><button type="button" class="btn btn-light" style="color: black !important;background: white !important;">Warrior Story <i class="far fa-hand-point-right"></i></button></a>
                    </div>
                    
                </div>
            </div>
        </div><!-- Modal Photo -->
        
    <?php } //End Photo ?>
        
        <!-- Modal photo -->
        <div class="modal fade"  id="photoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Change Your Picture</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" style="background: url(<?= base_url('inc/image/bg-photo.jpg'); ?>);
            background-size: 100%;">
                        <div class="container text-center my-3">
                            
                            <div class="owl-carousel">
                                <?php foreach ($photo as $p){ ?>
                                    <div> <img class="img-thumbnail img-show img-fluid z-depth-1-half rounded-circle" src="<?= base_url('inc/image/warriors/pp/'.$p->picture); ?>">
                                    <label class="badge badge-danger"><?= ucfirst($p->username); ?></span></div>
                                <?php } ?>
                              
                            </div>
        
            
                        </div>
                    </div>
                    
                    <div class="modal-footer bg-primary">
                        <a href="<?= base_url('account'); ?>"><button type="button" class="btn btn-light" style="color: black !important;background: white !important;">Change Now <i class="far fa-hand-point-right"></i></button></a>
                    </div>
                    
                </div>
            </div>
        </div><!-- Modal Photo  -->
    
    
    <?php if(!empty($birthdate)){ ?>
    
    
        <script type="text/javascript">
    
            $(document).ready(function(){
              $('#ultahModal').modal('show');
            });

        </script>

        <!--Modal: Ultah-->
        <div class="modal fade" id="ultahModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog cascading-modal modal-avatar modal-sm" role="document">
                <!--Content-->
                <div class="modal-content">
        
                    <!--Header-->
                    <div class="modal-header">
                        <?php foreach($birthdate as $b){ 
                            if(!empty($b->picture)){ ?>
                            <img src="https://apps.mri.co.id/inc/image/warriors/pp/<?= $b->picture; ?>" alt="avatar" class="img-thumbnail rounded-circle img-responsive">
                        <?php }else{ ?>
                            <img src="http://via.placeholder.com/130x130?text=no+picture" alt="avatar" class="img-thumbnail rounded-circle img-responsive">
                        <?php } } ?>
                    </div>
                    <!--Body-->
                    <div class="modal-body text-center mb-1">
        
                        <h5 class="mt-1 mb-2"><?php foreach($birthdate as $b){ echo ucfirst($b->username).' '; } ?></h5>
        
                        <?php $i=0; foreach($birthdate as $b){
                            $id[$i] = $b->id;
                            $i++;
                        } 
                        
                        if (in_array($this->session->userdata('id'), $id, TRUE)) { ?>
                              
                            <div class="md-form ml-0 mr-0 mb-2">
                                Happy Birthday to you <i class="far fa-smile"></i>
                            </div>
                              
                        <?php }else{ ?>
                          
                            <div class="md-form ml-0 mr-0 mb-2">
                                Hello guys, our friend <b><?php foreach($birthdate as $b){ echo ucfirst($b->username).' '; } ?></b>is now being a birthday. Don't forget to say happy birthday to him. <i class="far fa-smile"></i>
                            </div>
                          
                        <?php } ?>
    
                        
        
                    </div>
        
                </div>
                <!--/.Content-->
            </div>
        </div>
        <!--Modal: Login with Avatar Form-->

    
    <?php } //End Ultah ?>
        
        
    
    



<?php } ?>

 
 <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    
    <div class="content ">
     
      <div class="page-title"> <i class="icon-custom-left"></i>
        <h3>Dashboard <span class="semi-bold"></span></h3>
      </div>
      <div id="container">
      
		<div class="grid simple">
                
                <div class="grid-body no-border" style="display: block;"> <br>
                <div class="row">
                    <div class="col-md-7">
                        <div>
                            <!--<div class="alert alert-info" id="msg-info">
								<b> New Update Overtime</b>: Jika lembur dibawah 30 menit maka akan dianggap tidak lembur, jika diatas 30 menit maka dianggap lembur 30 menit.
							</div>-->
                            <h1 style="font-size: 50px;font-weight: 600;font-style: italic;letter-spacing: -1.3px;color: #0d4e6c;margin-top:20px;">Hello, <?php echo ucfirst($this->session->userdata('username')); ?></h1><p style="font-size: 20px;line-height: 1.4;letter-spacing: -.5px;color: #6f6f6f;">It’s good to have you here. What would you like to do?</p>
                        </div>
                        <div class="row mb-3">
                            <div class="col-12 col-md-6 my-1">
                                <img src="<?= base_url('inc/image/topteam.jpeg'); ?>" class="w-100">
                            </div>
                            <div class="col-12 col-md-6 my-1">
                                <img src="<?= base_url('inc/image/mrcc.jpeg'); ?>" class="w-100">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5"><img src="<?= base_url(); ?>inc/image/computer.png" class="animated bounceIn" style="width:100%;"></div>
                </div>
                <div class="row">
                    <?php if(!empty($overtime)){ ?>
                        <?php if($overtime > -1){ ?>
                            <div class="col-md-4" style="padding: 10px;background: #0d4e6c;color: white;margin:0px;border: 1px solid white;">
                        <?php }else{ ?>
                            <div class="col-md-4" style="padding: 10px;background: #f33837;color: white;margin:0px;border: 1px solid white;">
                        <?php } ?>
                            <span style="font-weight:bold;margin-left: 1px;">Overtime :</span><br>
                            <h1 class="my-3" style="font-size: 3em;color: white;font-weight:bold;text-align: center;"><?php echo $overtime; ?></h1>
                        </div>
                    <?php }else{ ?>
                        <div class="col-md-4" style="padding: 10px;background: #0d4e6c;color: white;margin:0px;border: 1px solid white;">
							<span style="font-weight:bold;margin-left: 1px;">Overtime :</span><br>
                            <h1 class="my-3" style="font-size: 3em;color: white;font-weight:bold;text-align: center;">0</h1>
                        </div>
                    <?php } ?>
                    <?php if(!empty($izin)){ ?>
                        <div class="col-md-4" style="padding: 10px;background: #33b5e5;color: white;margin:0px;border: 1px solid white;">
                            <span style="font-weight:bold;margin-left: 1px;">Cuti Izin :</span><br>
                            <h1 class="my-3" style="font-size: 3em;color: white;font-weight:bold;text-align: center;"><?php echo $izin; ?></h1>
                        </div>
                    <?php }else{ ?>
                        <div class="col-md-4" style="padding: 10px;background: #33b5e5;color: white;margin:0px;border: 1px solid white;">
                            <span style="font-weight:bold;margin-left: 1px;">Cuti Izin :</span><br>
                            <h1 class="my-3" style="font-size: 3em;color: white;font-weight:bold;text-align: center;">0</h1>
                        </div>
                    <?php } ?>
                    <?php if(!empty($sakit)){ ?>
                        <div class="col-md-4" style="padding: 10px;background: #33b5e5;color: white;margin:0px;border: 1px solid white;">
                            <span style="font-weight:bold;margin-left: 1px;">Cuti Sakit :</span><br>
                            <h1 class="my-3" style="font-size: 3em;color: white;font-weight:bold;text-align: center;"><?php echo $sakit; ?></h1>
                        </div>
                    <?php }else{ ?>
                        <div class="col-md-4" style="padding: 10px;background: #33b5e5;color: white;margin:0px;border: 1px solid white;">
                            <span style="font-weight:bold;margin-left: 1px;">Cuti Sakit :</span><br>
                            <h1 class="my-3" style="font-size: 3em;color: white;font-weight:bold;text-align: center;">0</h1>
                        </div>
                    <?php } ?>
                    
                </div>
                <hr>
                
			    <!--<center><img src="<?php echo base_url(); ?>assets/image/war.jpg" style="width: 500px;"></center>-->
                                                 
                </div>
                
                
                
              </div>
              
      </div>
      <!-- END PAGE -->
    </div>
  </div>
<!-- END CONTAINER -->
</div>




