<?php $active = $this->session->userdata('menu_active');?>
<!-- Sidebar Holder -->
<nav id="sidebar" class="dinamisTop" style="background: url(<?= base_url(); ?>inc/image/textureweb.jpg); background-size: 100% 100%;">

	<div class="text-center py-3" style="background: url(<?= base_url(); ?>inc/image/md.jpg);background-size:100% 100%;">
		<div class="row p-3 m-0">
			<div class="col-6">
				<?php 
				if(!empty($this->session->userdata('picture'))){
					$foto = base_url().'inc/image/warriors/pp/'.$this->session->userdata('picture');
				}else{
					$foto = base_url().'inc/image/user.png';
				}
				?>
				<img id="profile" src="<?= $foto?>" style="width: 80px;border-radius: 100%;position: relative;">
			</div>
			<div class="col-6 ml-0 pl-0">
				<p style="color:white;">Welcome, <br>
					<span style="color: #33b5e5;font-size: 1.5em;font-weight: bold;text-shadow: 0 0 3px black;"><?= ucfirst($this->session->userdata('username'))?></span>
				</p>
			</div>
		</div>				
	</div>

	<ul class="list-unstyled components">
		<!-- SIDEBAR USER -->
		<?php if($this->session->userdata('level') == 'user'){ ?>
		<li class="<?= (!empty($active) && $active == 'dashboard')? 'active':'';?>"> 
			<a href="<?= base_url('dashboard')?>"><i class="fa fa-home"></i>&nbsp Dashboard</a>
		</li>
		<li> 
			<a href="#menu1" data-toggle="collapse" aria-expanded="false"><i class="fas fa-clock"></i>&nbsp Overtime <span class="arrow"></span> </a>
			<ul class="collapse list-unstyled" id="menu1">
				<li class="<?= (!empty($active) && $active == 'Apply Overtime')? 'active':'';?>"> 
					<a href="<?= base_url('user/overtime/apply')?>">Apply Overtime</a>
				</li>
				<?php if(($this->session->userdata('is_spv') == true) OR ($this->session->userdata('is_mgr') == true)){ ?>
				
					<li class="<?= (!empty($active) && $active == 'Acc Overtime')? 'active':'';?>"> 
						<a href="<?= base_url('user/overtime/acc')?>">Acc Overtime <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;">'.$acc.'</label>'; } ?></a>
					</li>
					
				<?php } ?>
				<li class="<?= (!empty($active) && $active == 'Report')? 'active':'';?>"> 
					<a href="<?= base_url('user/overtime/history'); ?>">Jam Lembur</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Cuti Izin')? 'active':'';?>"> 
					<a href="<?= base_url('user/overtime/cuti_izin'); ?>">Cuti Izin</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Cuti Sakit')? 'active':'';?>"> 
					<a href="<?= base_url('user/overtime/cuti_sakit'); ?>">Cuti Sakit</a>
				</li>

			</ul>
		</li>
		<li> 
			<a href="#menu2" data-toggle="collapse" aria-expanded="false"><i class="fa fa-tasks"></i>&nbsp Task Allocation <span class="arrow"></span> </a>
			<ul class="collapse list-unstyled" id="menu2">
				<li class="<?= (!empty($active) && $active == 'My Task')? 'active':'';?>"> 
					<a href="<?= base_url('user/task'); ?>">My Task</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Request Task')? 'active':'';?>"> 
					<a href="<?= base_url('user/task/request'); ?>">List Permohonan Task <?php if($task_permite > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;">'.$task_permite.'</label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Submission Task')? 'active':'';?>"> 
					<a href="<?= base_url('user/task/submission'); ?>">List Pengajuan Task <?php if($task_submission > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;">'.$task_submission.'</label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'All Task')? 'active':'';?>"> 
					<a href="<?= base_url('user/task/all'); ?>">All Task</a>
				</li>
			</ul>
		</li>

		<li>
			<a href="#menu3" data-toggle="collapse" aria-expanded="false"><i class="fas fa-hand-holding-usd"></i>&nbsp Incentive</a>
			<ul class="collapse list-unstyled" id="menu3">

				<li class="<?= (!empty($active) && $active == 'Report Incentive')? 'active':'';?>"> 
					<a href="<?= base_url('user/incentive/report'); ?>">Report Incentive <?php if($report_incentive > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;">'.$report_incentive.'</label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Incentive')? 'active':'';?>"> 
					<a href="<?= base_url('user/incentive'); ?>">Incentive</a>
				</li>

			</ul>
		</li>
		<?php if((($this->session->userdata('is_spv') == true && $this->session->userdata('signup_privilege') == 1) || ($this->session->userdata('divisi') == 'MRCC-2') || $this->session->userdata('id') == 76) || $this->session->userdata('branch_leader') > 0){ ?>
		<li>
			<a href="#menu4" data-toggle="collapse" aria-expanded="false"><i class="fa fa-user-plus"></i>&nbsp Signup</a>
			<ul class="collapse list-unstyled" id="menu4">
				<li class="<?= (!empty($active) && $active == 'Add Signup')? 'active':'';?>"> 
					<a href="<?= base_url('user/signup')?>">Add Signup </a>
				</li>
				<?php 
					if($this->session->userdata('student_privilege') == 0){ 
					?>
					<li class="<?= (!empty($active) && $active == 'Add Repayment')? 'active':'';?>"> 
						<a href="<?= base_url('user/signup/add_repayment')?>">Add Pembayaran DP</a>
					</li>
				<?php	
					}
				?>
				<li class="<?= (!empty($active) && $active == 'List Signup')? 'active':'';?>"> 
					<a href="<?= base_url('user/signup/all')?>">List Signup</a>
				</li>
			</ul>
			
		</li>
		<?php } ?>
		
		<?php if($this->session->userdata('is_spv') == true && strpos($this->session->userdata('divisi'), 'MRLC') !== false){ ?>
		<li>
			<a href="#menu_rc" data-toggle="collapse" aria-expanded="false"><i class="fa fa-clone"></i>&nbsp Regular Class</a>
			<ul class="collapse list-unstyled" id="menu_rc">
				<li class="<?= (!empty($active) && $active == 'dashboard student')? 'active':'';?>""><a href="<?= base_url('rc/dashboard')?>">Dashboard Student </a></li>
				<li class="<?= (!empty($active) && $active == 'branch')? 'active':'';?>""><a href="<?= base_url('rc/branch')?>">Manage Branch </a></li>
				<li class="<?= (!empty($active) && $active == 'periode')? 'active':'';?>""><a href="<?= base_url('rc/periode')?>">Manage Periode </a></li>
				<li class="<?= (!empty($active) && $active == 'classroom')? 'active':'';?>"><a href="<?= base_url('rc/classroom')?>">Manage Class </a></li>
				<li class="<?= (!empty($active) && $active == 'trainer')? 'active':'';?>"><a href="<?= base_url('rc/trainer')?>">Manage Trainer </a></li>
				<li class="<?= (!empty($active) && $active == 'student')? 'active':'';?>"><a href="<?= base_url('rc/student/manage')?>">Manage Student </a></li>
				<li class="<?= (!empty($active) && $active == 'absensi')? 'active':'';?>"><a href="<?= base_url('rc/absensi')?>">Absensi </a></li>
				<li class="<?= (!empty($active) && $active == 'submission')? 'active':'';?>"><a href="<?= base_url('rc/student/submission')?>">List Pengajuan Pindah </a></li>
			</ul>
			
		</li>
		<?php }?>

		<?php if($this->session->userdata('is_spv') == false && strpos($this->session->userdata('divisi'), 'MRLC') !== false){ ?>

			<li>
			<a href="#menu_trainer" data-toggle="collapse" aria-expanded="false"><i class="fa fa-clone"></i>&nbsp Regular Class</a>
			<ul class="collapse list-unstyled" id="menu_trainer">
				<li class="<?= (!empty($active) && $active == 'dashboard student')? 'active':'';?>""><a href="<?= base_url('rc/dashboard')?>">Dashboard Student </a></li>
				<li class="<?= (!empty($active) && $active == 'absensi')? 'active':'';?>"><a href="<?= base_url('rc/absensi')?>">Absensi </a></li>
				<li class="<?= (!empty($active) && $active == 'student')? 'active':'';?>"><a href="<?= base_url('rc/student/manage')?>">Manage Student </a></li>
				<li class="<?= (!empty($active) && $active == 'submission')? 'active':'';?>"><a href="<?= base_url('rc/student/submission')?>">Pengajuan Pindah </a></li>
			</ul>
			
		</li>
		<?php }?>
		<!--<li class="<?= (!empty($active) && $active == 'Uang Masuk')? 'active':'';?>"> 
			<a href="<?= base_url('user/incentive/uang_masuk'); ?>"> <i class="fa fa-check"></i>&nbsp Check Uang Masuk</a>
		</li>-->
		
		<!--<li>
			<a href="#menu5" data-toggle="collapse" aria-expanded="false"><i class="fas fa-box-open"></i>&nbsp Logistic <i style="font-size: 0.70em;color: orange;">(Beta)</i></a>
			<ul class="collapse list-unstyled" id="menu5">

				<li class="<?= (!empty($active) && $active == 'Logistic')? 'active':'';?>"> 
        			<a href="<?= base_url('user/logistic'); ?>">Tools</a>
        		</li>
				<li class="<?= (!empty($active) && $active == 'Logistic Request')? 'active':'';?>"> 
					<a href="<?= base_url('user/logistic/request'); ?>">Request Tools <?php if($my_request_product > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;">'.$my_request_product.'</label>'; } ?></a>
				</li>

			</ul>
		</li>-->
		
		

		<li class="<?= (!empty($active) && $active == 'Bird Test')? 'active':'';?>"> 
			<a href="<?= base_url('birdtest'); ?>"> <i class="fab fa-phoenix-framework"></i>&nbsp Bird Test</a>
		</li>

		<?php } ?>

		<!-- SIDEBAR ADMIN -->
		<?php if($this->session->userdata('level')=='admin'){ ?>
		<li class="<?= (!empty($active) && $active == 'dashboard')? 'active':'';?>"> 
			<a href="<?= base_url('dashboard'); ?>"> <i class="fa fa-home"></i>&nbsp Dashboard</a>
		</li>
		<li class="<?= (!empty($active) && $active == 'Data Divisi')? 'active':'';?>"> 
			<a href="<?= base_url('admin/divisi'); ?>"> <i class="fas fa-shield-alt"></i>&nbsp Divisi & Manager <small class="text-warning"><i>Beta Version</i></small></a>
		</li>
		<li class="<?= (!empty($active) && $active == 'Management HR')? 'active':'';?>"> 
			<a href="<?= base_url('admin/hr'); ?>"> <i class="fas fa-hands"></i>&nbsp Management HR <small class="text-warning"><i>On Progress</i></small></a>
		</li>
		<li class="<?= (!empty($active) && $active == 'Data User')? 'active':'';?>"> 
			<a href="<?= base_url('admin/user'); ?>"> <i class="fa fa-user"></i>&nbsp User</a>
		</li>
		<li class="<?= (!empty($active) && $active == 'Data User')? 'active':'';?>">
			<a href="<?= base_url('admin/user/data'); ?>"> <i class="fa fa-user"></i>&nbsp Data User <small class="badge badge-primary">Download</small></a>
		</li>

		<li class=""> 
			<a href="#menu6" data-toggle="collapse" aria-expanded="false"> <i class="fa fa fa-adjust"></i>&nbsp Cuti / Lembur <span class="arrow"></span></a>
			<ul class="collapse list-unstyled" id="menu6">
				<li class="<?= (!empty($active) && $active == 'Overtime')? 'active':'';?>"> 
					<a href="<?= base_url('admin/overtime'); ?>">Jam Lembur</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Acc Lembur')? 'active':'';?>"> 
					<a href="<?= base_url('admin/overtime/acc'); ?>">Acc Lembur</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Report HR')? 'active':'';?>"> 
					<a href="<?= base_url('admin/overtime/report_hr'); ?>">L-HR (Jam Lembur)</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Report Izin')? 'active':'';?>"> 
					<a href="<?= base_url('admin/overtime/report_izin_hr'); ?>">L-HR (Cuti) Detail Izin</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Report Sakit')? 'active':'';?>"> 
					<a href="<?= base_url('admin/overtime/report_sakit_hr'); ?>">L-HR (Cuti) Detail Sakit</a>
				</li>
			</ul>
		</li>

		<li class="<?= (!empty($active) && $active == 'Loker')? 'active':'';?>">
			<a href="<?= base_url('admin/loker'); ?>"> <i class="fa fa-suitcase"></i>&nbsp Loker</a>
		</li>
		<li class="<?= (!empty($active) && $active == 'Birdtest Report')? 'active':'';?>">
			<a href="<?= base_url('birdtest/report'); ?>"> <i class="fab fa-phoenix-framework"></i>&nbsp Bird Test</a>
		</li>


		<?php } ?>
		
		
		<!-- SIDEBAR HR-->
		<?php if($this->session->userdata('level')=='hr'){ ?>
		
		<li class="<?= (!empty($active) && $active == 'dashboard')? 'active':'';?>"> 
			<a href="<?= base_url('dashboard'); ?>"> <i class="fa fa-home"></i>&nbsp Dashboard</a>
		</li>
		<li class="">
				<li class="<?= (!empty($active) && $active == 'Overtime')? 'active':'';?>"> 
					<a href="<?= base_url('hr/overtime'); ?>"> <i class="fas fa-clock"></i>&nbsp Jam Lembur</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Acc Lembur')? 'active':'';?>"> 
					<a href="<?= base_url('hr/overtime/acc'); ?>"> <i class="fas fa-clipboard-check"></i>&nbsp Acc Lembur</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Report HR')? 'active':'';?>"> 
					<a href="<?= base_url('hr/overtime/report_hr'); ?>"> <i class="fas fa-clipboard-list"></i>&nbsp L-HR (Jam Lembur)</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Report Izin')? 'active':'';?>"> 
					<a href="<?= base_url('hr/overtime/report_izin_hr'); ?>"> <i class="fas fa-clipboard-list"></i>&nbsp L-HR (Cuti Izin)</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Report Sakit')? 'active':'';?>"> 
					<a href="<?= base_url('hr/overtime/report_sakit_hr'); ?>"><i class="fas fa-clipboard-list"></i>&nbsp L-HR (Cuti Sakit)</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Data User')? 'active':'';?>">
        			<a href="<?= base_url('hr/user'); ?>"> <i class="fa fa-user"></i>&nbsp Data User <small class="badge badge-primary">Download</small></a>
        		</li>
        		<li class="<?= (!empty($active) && $active == 'Loker')? 'active':'';?>">
        			<a href="<?= base_url('hr/loker'); ?>"> <i class="fa fa-suitcase"></i>&nbsp Loker</a>
        		</li>
		</li>
		<?php } ?>
		
		
		<!-- SIDEBAR FINANCE -->
		<?php if($this->session->userdata('level')=='finance'){ ?>
		<li>
			<a href="#menu7" data-toggle="collapse" aria-expanded="true"><i class="fa fa-user-plus"></i>&nbsp Signup</a>
			<ul class="collapse list-unstyled show" id="menu7">
				<li class="<?= (!empty($active) && $active == 'Confirm Signup')? 'active':'';?>"> 
					<a href="<?= base_url('finance/signup/confirm')?>">Confirm Signup <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Confirm Repayment')? 'active':'';?>"> 
					<a href="<?= base_url('finance/signup/confirm_repayment')?>">Confirm DP</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Set Batch')? 'active':'';?>"> 
					<a href="<?= base_url('finance/signup/batch')?>">Set Batch <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Master Data Transaksi')? 'active':'';?>"> 
					<a href="<?= base_url('finance/signup/master')?>">Data Transaksi <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Master Data Peserta')? 'active':'';?>"> 
					<a href="<?= base_url('finance/signup/master_participant')?>">Data Participant <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
			</ul>
			
		</li>
		<li>
			<a href="#menu9" data-toggle="collapse" aria-expanded="false"><i class="fas fa-hand-holding-usd"></i>&nbsp Incentive</a>
			<ul class="collapse list-unstyled" id="menu9">

				<li class="<?= (!empty($active) && $active == 'Future Task')? 'active':'';?>"> 
					<a href="<?= base_url('finance/incentive/future'); ?>">Future Task</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Last Task')? 'active':'';?>"> 
					<a href="<?= base_url('finance/incentive'); ?>">Last Task</a>
				</li>

			</ul>
		</li>
		<li class="<?= (!empty($active) && $active == 'Money Checker')? 'active':'';?>">
			<a href="<?= base_url('finance/incentive/moneychecker'); ?>"> <i class="fa fa-check"></i>&nbsp Cek Uang Masuk</a>
		</li>
		<?php } ?>
		
		<!-- SIDEBAR SUPPORT -->
		<?php if($this->session->userdata('level')=='support'){ ?>
		<li> 
			<a href="#menu10" data-toggle="collapse" aria-expanded="true"><i class="fa fa-book"></i>&nbsp Task Allocation</a>
			<ul class="collapse list-unstyled show" id="menu10">
				<li class="<?= (!empty($active) && $active == 'Future Task Support')? 'active':'';?>"> 
					<a href="<?= base_url('support/task');?>">Future Task</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Last Task Support')? 'active':'';?>"> 
					<a href="<?= base_url('support/task/all'); ?>">Last Task</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'List Incentive')? 'active':'';?>"> 
					<a href="<?= base_url('support/task/list_incentive'); ?>">List Incentive SP</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Overview Task')? 'active':'';?>"> 
					<a href="<?= base_url('support/task/overview'); ?>">Report Task Allocation</a>
				</li>			
			</ul>
		</li>
		<?php } ?>
		
		<!-- SIDEBAR LOGISTIC -->
		<?php if($this->session->userdata('level')=='logistic'){ ?>
		<li> 
			<a href="#menu11" data-toggle="collapse" aria-expanded="true"><i class="fa fa-book"></i>&nbsp Product</a>
			<ul class="collapse list-unstyled show" id="menu11">
				<li class="<?= (!empty($active) && $active == 'Product')? 'active':'';?>"> 
					<a href="<?= base_url('logistic/product');?>">Product</a>
				</li>
				<!--<li class="<?= (!empty($active) && $active == 'List Request')? 'active':'';?>"> 
					<a href="<?= base_url('logistic/product/request'); ?>">List Request <?php if($request_product > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;">'.$request_product.'</label>'; } ?></a>
				</li>-->
				<li class="<?= (!empty($active) && $active == 'Event Request')? 'active':'';?>"> 
					<a href="<?= base_url('logistic/product/event_request'); ?>">Event Request <?php //if($event_request_product > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;">'.$event_request_product.'</label>'; } ?></a>
				</li>
			</ul>
		</li>
		<?php } ?>
		
		<!-- SIDEBAR viewer -->
		<?php if($this->session->userdata('level')=='viewer'){ ?>
		<li>
			<a href="#menu7" data-toggle="collapse" aria-expanded="true"><i class="fa fa-user-plus"></i>&nbsp Signup</a>
			<ul class="collapse list-unstyled show" id="menu7">
				<li class="<?= (!empty($active) && $active == 'Confirm Signup')? 'active':'';?>"> 
					<a href="<?= base_url('viewer/signup/confirm')?>">Confirm Signup <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Confirm Repayment')? 'active':'';?>"> 
					<a href="<?= base_url('viewer/signup/confirm_repayment')?>">Confirm Pembayaran DP</a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Set Batch')? 'active':'';?>"> 
					<a href="<?= base_url('viewer/signup/batch')?>">Set Batch <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Master Data Transaksi')? 'active':'';?>"> 
					<a href="<?= base_url('viewer/signup/master')?>">Data Transaksi <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
				<li class="<?= (!empty($active) && $active == 'Master Data Peserta')? 'active':'';?>"> 
					<a href="<?= base_url('viewer/signup/master_participant')?>">Data Peserta <?php if($acc > 0){ echo '<label class="badge badge-light float-right" style="cursor: auto;font-weight:bold;"></label>'; } ?></a>
				</li>
			</ul>
			
		</li>
		<?php }?>
		
	</ul>

</nav>

<div id="content" class="dinamisTop">