				<div class="col-md-8">
					<div id='calendar'></div>
				</div>
				<div class="col-md-2">
					<div class="panel panel-default" style="background:#337ab7;color:white;font-weight:bold;text-align:center;">
					  <div class="panel-body">
					    <div><i class="fa fa-clock-o" aria-hidden="true"></i>
 Jam lembur</div>
					    <h3 style="font-size:4em;font-weight:bold;">50</h3>
					  </div>
					</div>
				</div>