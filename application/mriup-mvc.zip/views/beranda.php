</div>
<div class="row">
<div class="col-md-6 col-xlg-5">
	<div class="row">
		<div class="col-md-12 m-b-10">
			<div class="ar-3-2 widget-1-wrapper">
				<div class="widget-1 panel no-border bg-abu-abu no-margin widget-loader-circle-lg">
					<div class="panel-heading top-right ">
						<div class="panel-controls">
							<ul>
								<li>
								<a data-toggle="refresh" class="portlet-refresh text-black" href="#"><i class="portlet-icon portlet-icon-refresh-lg-master"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="panel-body">
						<div class="pull-bottom bottom-left bottom-right ">
							<span class="label font-montserrat fs-11">PEMBERITAHUAN</span>
							<br>
							<h2 class="text-white">Pemberitahuan untuk para Warriors</h2>
							<p class="text-white hint-text">
								Dapatkan informasi up to date
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6 m-b-10">
			<div class="ar-2-1">
				<div class="widget-4 bg-abu-abu panel no-border no-margin widget-loader-bar">
				</div>
			</div>
		</div>
		<div class="col-sm-6 m-b-10">
			<div class="ar-2-1">
				<div class="widget-5 bg-abu-abu panel no-border widget-loader-bar">
				</div>
			</div>
		</div>
	</div>
</div>
<div class="col-md-6 col-xlg-4">
	<div class="row">
		<div class="col-sm-6 m-b-10">
			<div class="ar-1-1">
				<div class="widget-2 panel no-border bg-master-dark widget widget-loader-circle-lg no-margin">
					<div class="panel-heading">
						<div class="panel-controls">
							<ul>
								<li>
								<a href="#" class="portlet-refresh" data-toggle="refresh"><i class="portlet-icon portlet-icon-refresh-lg-white"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="panel-body">
						<div class="pull-bottom bottom-left bottom-right padding-25">
							<span class="label font-montserrat fs-11">JAM LEMBUR</span>
							<br>
							<h3 class="text-white"><strong>Lihat spesifik jam lebur kamu</strong></h3>
							<p class="text-white hint-text hidden-md">
								kamu juga bisa melihat event MRI
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--akhir kotak ke 2, kanan atas-->
		<div class="col-sm-6 m-b-10">
			<div class="ar-1-1">
				<div class="widget-3 panel no-border bg-abu-abu no-margin widget-loader-bar">
					<div style="text-align: center;font-size: 1.5em;color: white;margin-top: 120px;font-weight: bold;">
						 Coming Soon
					</div>
				</div>
			</div>
		</div>
		<!--akhir kotak ke 2, kanan atas-->
	</div>
	<div class="row">
		<!--akhir kotak ke 3, kanan bawah-->
		<div class="col-sm-6 m-b-10">
			<div class="ar-1-1">
				<div class="panel no-border bg-abu-abu widget widget-loader-circle-lg no-margin">			
					<div style="text-align: center;font-size: 1.5em;color: white;margin-top: 120px;font-weight: bold;">
						 Coming Soon
					</div>
				</div>
			</div>
		</div>
		<!--akhir kotak ke 3, kanan bawah-->
		<!--kotak ke-4, kanan bawah-->
		<div class="col-sm-6 m-b-10">
			<div class="ar-1-1">
				<div class="widget-7 panel no-border bg-abu-abu no-margin">
				<img alt="avatar" class="" src="/assets/profile/pp/<?php echo $this->session->userdata('picture'); ?>" style="width:100%;">
					<div style="text-align: center;font-size: 1.5em;color: white;margin-top: 120px;font-weight: bold;">
						 Coming Soon
					</div>
				</div>
			</div>
		</div>
		<!--akhir kotak ke 4, kanan bawah-->
	</div>
</div>
